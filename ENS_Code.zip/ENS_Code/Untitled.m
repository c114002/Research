clc
V = rand(5,1);
iscolumn(V)