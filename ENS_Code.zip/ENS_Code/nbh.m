function nbh = Mat(mat,yd)
global B_row
global B_col
global N_row
global nj
global nc
global N_col

% yd = load('lym.dat');
ydcols= size(yd,2);%%
ydrows= size(yd,1);
rowalpha=0.1;%%
colbeta=0.003;%%
rows=size(mat, 1);
cols=size(mat, 2);
aiJ=mean(mat,2);
aiJ=aiJ';
aIj=mean(mat,1);
sum=0;
di=zeros(ydrows,1);
dj=zeros(ydcols,1);
for i=1:rows
    for j=1:cols
        sum=sum+mat(i,j);
    end 
end
aIJ=sum/(rows*cols);
for i=1:rows
    disum=0;
    for j=1:cols
       mid= ((mat(i,j)-aiJ(i)-aIj(j)+aIJ).^2);
       disum= disum+mid;
    end
    dii=disum/cols;
    djj=disum/rows;
    di(i)=dii;
    dj(i)=djj;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sumdi1=0;%% checking for rowscore
for i=1:length(di)
    sumdi1=di(i,1)+sumdi1;
end
sumdj=0;%% checking for colscore
for i=1:length(dj)
    sumdj=dj(i,1)+sumdj;
end
if sumdi1==0%% if matrix has 0 rowscore code
    B_row=[];
    
    row1=1;
    while(row1~=10)
         ind = ceil(rand * size(yd,1));
         B_row(1,row1)=ind;
         mrow = yd(ind,:);
         for i=1:size(mrow,2)
                mat(row1,i)=mrow(1,i);
         end
         row1=row1+1;
    end
rows=size(mat, 1);
cols=size(mat, 2);
aiJ=mean(mat,2);
aiJ=aiJ';
aIj=mean(mat,1);
sum1=0;
for i=1:rows
    for j=1:cols
        sum1=sum1+mat(i,j);
    end 
end
aIJ=sum1/(rows*cols);
di=zeros(rows,1);
dj=zeros(cols,1);
for i=1:rows
    disum=0;
    for j=1:cols
       mid= ((mat(i,j)-aiJ(i)-aIj(j)+aIJ).^2);
       disum= disum+mid;
    end
    dii=disum/cols;
    djj=disum/rows;
   dj(i)=djj;
   di(i)=dii;
end 
elseif sumdi1~=0 %% rowscore not 0
    
   alpha=di>rowalpha; 
   sumdii=0;
   for i=1:length(alpha)
    sumdii=alpha(i,1)+sumdii;
   end 
if sumdii~=0
    jbr=1;
  for i=1:size(B_row,1)
    if(B_row(i,1) && alpha(i,1)~=0)
       new_brow(jbr,1)= B_row(i,1);
       jbr=jbr+1;
    end 
  end
  ind = ceil(rand * size(yd,1));
  newrow = yd(ind,:);
  B_row =new_brow;
  browsize=size(B_row,1);
  B_row((browsize+1),1)=ind;
  B_row=unique(B_row);
  indc = ceil(rand * size(yd,2));
  newcol = yd(:,indc);  
  cs=size(B_col,2);
  B_col(1,(cs+1))=indc;
  B_col=unique(B_col);
  B_col=B_col(B_col~=0);
  B_row=B_row(B_row~=0);
  for i=1:size(B_row,1)
      for j=1:size(B_col,2)
          mat(i,j)=yd(B_row(i),B_col(j));
      end
  end
end
end %% if matrix has 0 rowscore ends

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if sumdi1==0 || sumdii==0
alpha=di>rowalpha;
sumdi=0;
counter2=1;
for i=1:length(alpha)
    sumdi=alpha(i,1)+sumdi;
end

while(sumdi==0 && counter2~=100)% if no alpha row
    
    B_row=[];
    row1=1;
     while(row1~=10)
         ind = ceil(rand * size(yd,1));
         B_row(1,row1)=ind;
         mrow = yd(ind,:);
         for i=1:size(mrow,2)
                mat(row1,i)=mrow(1,i);
         end
         row1=row1+1;
    end
rows=size(mat,1);
cols=size(mat,2);
aiJ=mean(mat,2);
aiJ=aiJ';
aIj=mean(mat,1);
sum2=0;
for i=1:rows
    for j=1:cols
        sum2=sum2+mat(i,j);
    end 
end
aIJ=sum2/(rows*cols);
di=zeros(rows,1);
dj=zeros(cols,1);
for i=1:rows
    disum=0;
    for j=1:cols
       mid= ((mat(i,j)-aiJ(i)-aIj(j)+aIJ).^2);
       disum= disum+mid;
    end
    dii=disum/cols;
    djj=disum/rows;
   di(1,i)=dii;
   dj(1,i)=djj;
end 
alpha=di>rowalpha;
sumdi=0;
for i=1:length(alpha)
    sumdi=alpha(i,1)+sumdi;
end
counter2=counter2+1;
end % no alpha row while loop ends
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B_row=unique(B_row);
B_col=unique(B_col);
if iscolumn(B_row)
    B_row=B_row';
end
for i=1:length(B_row)
    N_row(1,nc)= B_row(1,i);
    nc=nc+1;
end
for j=1:length(B_col)
    N_col(1,nj)= B_col(1,j);
    nj=nj+1;
end
N_row=unique(N_row);
N_col=unique(N_col);
P_row=N_row(N_row~=0);
P_col=N_col(N_col~=0);
for i=1:length(P_row)
    for j=1:length(P_col)
      OP_bi(i,j)= yd(P_row(i),P_col(j));
    end
end
nbh=OP_bi;
end

