function SM =avss(x)
try
first_th=0.4;
sec_th=0.5;
no_rows=size(x,1);
no_cols=size(x,2);
rr = randi(no_rows);
rc = randi(no_cols);
y=x(rr,rc);
Dij=abs(minus(x,y));
Davg= Dij./(no_rows * no_cols);
if Dij== (first_th*Davg)
    SM=0;
elseif Dij> (first_th*Davg)
    SM=0;
else
    sm1=Dij./(first_th*Davg);
    SM=1-(sm1+sec_th);
end
catch
    
    SM=0;
    
end

end