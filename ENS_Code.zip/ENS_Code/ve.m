function ve=veb(x)
rowsve=size(x,1);
colsve=size(x,2);
sigma_g_j=std(x,0,2);
pmean=mean(x);
col_mean=mean(x,1);
sigma_p=std(x,0,1);

for i=1:colsve
    for j=1:rowsve
       Bij(i,j)= ((x(j,i)-x(j,colsve))/sigma_g_j(j));
    end
end
for i=1:colsve
    for j=1:rowsve
      P(i)=(x(j,i)/rowsve);
    end
     P_dash(i)=(P(i)-pmean(i))/sigma_p(i);
end
for i=1:colsve
    for j=1:rowsve
       ve(i,j)= (Bij(i,j)-P_dash(i))/(rowsve*colsve);
    end
end        
ve=min(ve(:));
end

        
        
        
