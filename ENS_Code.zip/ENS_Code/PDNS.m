function op = PDNS(r,yd)
global N_row
global N_col
% yd = load('lym.dat');
no_it=500;
count=0;
while count < no_it
  bi=nbh(r,yd);
  r=bi;
  count=count+1;
end
nbh_rows_output=size(r,1)
nbh_cols_output=size(r,2)
B_sm=avss(r);
    maxB= max(B_sm(:));
    P_row=N_row(N_row~=0);
    P_col=N_col(N_col~=0);
    len=length(P_row);
   for i=1:(round(len/2))
        for j=1:length(P_col)
         OP_avssb1(i,j)= yd(P_row(i),P_col(j));
        end
   end
   for i= (round(len/2)+1):len
        for j=1:length(P_col)
         OP_avssb2(i,j)= yd(P_row(i),P_col(j));
        end
   end
     OP_avssb1_sm=avss(OP_avssb1);
     OP_avssb2_sm=avss(OP_avssb2);
     max1= max(OP_avssb1_sm(:));
     max2= max(OP_avssb2_sm(:));
     if max1>max2 || max1==max2
         maxnw=max1;
         clus=1;
     else
         maxnw=max2;
         clus=2;
     end
     if maxnw>maxB || maxnw==maxB
         if clus==1
           final_avss_bi=OP_avssb1;
         elseif clus==2
            final_avss_bi=OP_avssb1; 
         end
     else
      final_avss_bi=r;   
     end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ASR%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
asrcount=0;
maxasr=ASR(final_avss_bi);
final_asr_bi=final_avss_bi;
row_after_avss=size(final_avss_bi,1);
col_after_avss=size(final_avss_bi,2);
while(asrcount~=200)
     rr = randi(8);
    for i=1:(round(row_after_avss/rr))
        for j=1:col_after_avss
         OP_asrb1(i,j)= final_avss_bi(i,j);
        end
   end
   for i= (round(row_after_avss/rr)+1):row_after_avss
        for j=1:col_after_avss
         OP_asrb2(i,j)= final_avss_bi(i,j);
        end
   end
   a1=ASR(OP_asrb1);
   a2=ASR(OP_asrb2);
   if a1>maxasr||a1==maxasr
       final_asr_bi=OP_asrb1;
   elseif a2>maxasr||a2==maxasr
       final_asr_bi=OP_asrb2;
   end    
asrcount=asrcount+1;   
end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ve
vecount=0;
row_after_asr=size(final_asr_bi,1);
col_after_asr=size(final_asr_bi,2);
ve_whole=ve(final_asr_bi);
while(vecount~=200)
     rrv = randi(8);
    for i=1:(round(row_after_asr/rrv))
        for j=1:col_after_asr
         OP_veb1(i,j)= final_asr_bi(i,j);
        end
   end
   for i= (round(row_after_asr/rrv)+1):row_after_asr
        for j=1:col_after_asr
         OP_veb2(i,j)= final_asr_bi(i,j);
        end
   end
   ve1=ve(OP_veb1);
   ve2=ve(OP_veb2);
     if ve1<ve2 && ve1<ve_whole
        final_ve_bi=OP_veb1;
     elseif ve2<ve1 && ve2<ve_whole
        final_ve_bi=OP_veb2 ;
     else
       final_ve_bi=final_asr_bi;
     end
vecount=vecount+1;   
end
final_ve_bi(all(final_ve_bi==0,2),:)=[];
op=final_ve_bi;
esmbl_rows_output=size(final_ve_bi,1)
esmbl_cols_output=size(final_ve_bi,2)
 end
    

                    