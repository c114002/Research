function asr=ASR(x)
try
row=size(x,1);
col=size(x,2);
X=x(:);
mid=x';
Y=mid(:);
[RHO]=corr(X,Y,'Type','Spearman');
e=(RHO);
asr1=e/(row*(row-1));
asr2=e/(col*(col-1))  ;
if asr1>asr2
    asr=2*asr1;
else
    asr=2*asr2;
end
catch
    asr=0;
   
end


end
