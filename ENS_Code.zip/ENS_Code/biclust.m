function res = biclust(data, method)




      options = struct('cc_alpha',1.7, 'delta',0.5, 'numbiclust',10, 'random', ...
                       false);
  
  


      res = cc(data, options.cc_alpha, options.delta, options.numbiclust, ...
               options.random);
 

