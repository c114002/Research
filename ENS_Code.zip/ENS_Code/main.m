clc
global B_row
global B_col
global nj
global N_row
global nc
global N_col
nj=1;
nc=1;
% data=tdfread('E:\Elsevier\ENS_KS\GSE60402_MGE_expression.tab');
% data=xlsread('E:\Elsevier\111.xls')
tic;
load('E:\Elsevier\wt2_data.mat'); % load matrix
data = wt2_data;
rown=size(data,1);
coln=size(data,2);
N_row=zeros(1,rown);
N_col=zeros(1,1000);
result = biclust(data, 'cc');
c=result.Clust;%% choosing the biggest cluster
count=0;
max=-1;
for i = 1 : length(c)
    if length(c(i).rows)*length(c(i).cols)>count
        max=i;
        count=length(c(i).rows)*length(c(i).cols);
    end
end
B_row=c(max).rows;
B_col=c(max).cols;
r=data(c(max).rows,c(max).cols);%% Running PDNS
B=PDNS(r,data);
toc;
  



